#include<bits/stdc++.h>
using namespace std;
int main(){
    int a,b,c,d;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    printf("%d\n",56*a+24*b+14*c+6*d);
    return 0;
}
